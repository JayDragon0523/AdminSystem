#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <string.h>
main()
{
	int i=0;
	for(i=0;i<1000;i++)
	{
		printf("message is printed\n");
		sleep(5);
	}
}

